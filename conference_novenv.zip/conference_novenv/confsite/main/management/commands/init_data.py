from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from main.models import Room, BookingStatus

class Command(BaseCommand):
    help = 'Заполнение начальными данными'

    def handle(self, *args, **kwargs):
        # Создание статусов
        statuses = ['Новая', 'Мероприятие назначено', 'Мероприятие завершено']
        for name in statuses:
            BookingStatus.objects.get_or_create(name=name)
        
        # Создание помещений
        rooms = [
            {'name': 'Пленарный зал', 'room_type': 'auditorium', 'capacity': 200, 'price_per_hour': 5000, 'description': 'Большой зал для пленарных заседаний'},
            {'name': 'Лофт "Творчество"', 'room_type': 'coworking', 'capacity': 50, 'price_per_hour': 2000, 'description': 'Пространство для нетворкинга'},
            {'name': 'Кинозал', 'room_type': 'cinema', 'capacity': 80, 'price_per_hour': 3500, 'description': 'Профессиональный кинозал'},
            {'name': 'Малый зал', 'room_type': 'auditorium', 'capacity': 40, 'price_per_hour': 2500, 'description': 'Для узкого круга участников'},
        ]
        for r in rooms:
            Room.objects.get_or_create(**r)
        
        # Создание администратора (логин: Admin26, пароль: Demo20)
        admin, created = User.objects.get_or_create(
            username='Admin26',
            defaults={
                'is_staff': True,
                'is_superuser': True,
                'first_name': 'Администратор'
            }
        )
        if created:
            admin.set_password('Demo20')
            admin.save()
        
        # Создание тестового клиента
        client, created = User.objects.get_or_create(
            username='client',
            defaults={'first_name': 'Тестовый', 'last_name': 'Клиент'}
        )
        if created:
            client.set_password('client123')
            client.save()
        
        self.stdout.write(self.style.SUCCESS('✅ Данные успешно загружены!'))
        self.stdout.write(self.style.SUCCESS('Админ: Admin26 / Demo20'))
        self.stdout.write(self.style.SUCCESS('Клиент: client / client123'))