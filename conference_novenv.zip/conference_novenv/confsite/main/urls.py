from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile, name='profile'),
    path('booking/<int:room_id>/', views.create_booking, name='create_booking'),
    path('review/<int:booking_id>/', views.leave_review, name='leave_review'),
    path('admin_panel/', views.admin_panel, name='admin_panel'),
    path('status/<int:booking_id>/', views.change_status, name='change_status'),
    path('review_view/<int:booking_id>/', views.view_review, name='view_review'),
]