from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from django.db.models import Q
from .models import Room, Booking, BookingStatus, Review
from django.contrib.auth.models import User

def home(request):
    rooms = Room.objects.all()
    return render(request, 'main/home.html', {'rooms': rooms})

def register(request):
    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        login_input = request.POST.get('login')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        email = request.POST.get('email')
        
        error = None
        if not full_name or not login_input or not password:
            error = 'Заполните все поля'
        elif len(login_input) < 6 or not login_input.isalnum():
            error = 'Логин: 6+ символов (латиница/цифры)'
        elif len(password) < 8:
            error = 'Пароль: минимум 8 символов'
        elif password != password2:
            error = 'Пароли не совпадают'
        elif User.objects.filter(username=login_input).exists():
            error = 'Логин занят'
        
        if error:
            messages.error(request, error)
        else:
            user = User.objects.create_user(username=login_input, password=password, email=email, first_name=full_name)
            messages.success(request, 'Регистрация успешна!')
            return redirect('login')
    return render(request, 'main/register.html')

def login_view(request):
    if request.method == 'POST':
        user = authenticate(request, username=request.POST.get('login'), password=request.POST.get('password'))
        if user:
            login(request, user)
            return redirect('home')
        messages.error(request, 'Неверный логин или пароль')
    return render(request, 'main/login.html')

def logout_view(request):
    logout(request)
    return redirect('home')

@login_required
def profile(request):
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('full_name')
        user.email = request.POST.get('email')
        pwd = request.POST.get('password')
        if pwd:
            if len(pwd) >= 8:
                user.set_password(pwd)
                user.save()
                messages.success(request, 'Пароль изменен, войдите заново')
                return redirect('login')
            messages.error(request, 'Пароль: 8+ символов')
        user.save()
        messages.success(request, 'Профиль обновлен')
        return redirect('profile')
    
    bookings = Booking.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'main/profile.html', {'bookings': bookings, 'statuses': BookingStatus.objects.all()})

@login_required
def create_booking(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    if request.method == 'POST':
        booking = Booking.objects.create(
            user=request.user, room=room,
            event_date=request.POST.get('event_date'),
            start_time=request.POST.get('start_time'),
            duration_hours=int(request.POST.get('duration_hours', 2)),
            payment_method=request.POST.get('payment_method'),
            status=BookingStatus.objects.first()
        )
        messages.success(request, f'Заявка на "{room.name}" отправлена!')
        return redirect('profile')
    return render(request, 'main/create_booking.html', {'room': room})

@login_required
def leave_review(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    completed = BookingStatus.objects.get(name='Мероприятие завершено')
    if booking.status != completed:
        messages.error(request, 'Отзыв только после завершения')
        return redirect('profile')
    if Review.objects.filter(booking=booking).exists():
        messages.error(request, 'Отзыв уже есть')
        return redirect('profile')
    
    if request.method == 'POST':
        Review.objects.create(booking=booking, text=request.POST.get('text'), rating=int(request.POST.get('rating', 5)))
        messages.success(request, 'Спасибо за отзыв!')
        return redirect('profile')
    return render(request, 'main/leave_review.html', {'booking': booking})

@staff_member_required
def admin_panel(request):
    bookings = Booking.objects.all().order_by('-created_at')
    search = request.GET.get('search', '')
    if search:
        bookings = bookings.filter(Q(user__first_name__icontains=search) | Q(room__name__icontains=search))
    
    status_filter = request.GET.get('status', '')
    if status_filter:
        bookings = bookings.filter(status_id=status_filter)
    
    page = int(request.GET.get('page', 1))
    per_page = 10
    total = bookings.count()
    start = (page-1)*per_page
    bookings = bookings[start:start+per_page]
    
    return render(request, 'main/admin_panel.html', {
        'bookings': bookings, 'statuses': BookingStatus.objects.all(),
        'search': search, 'status_filter': status_filter, 'page': page,
        'total_pages': (total+per_page-1)//per_page if total else 1, 'total': total
    })

@staff_member_required
def change_status(request, booking_id):
    if request.method == 'POST':
        b = get_object_or_404(Booking, id=booking_id)
        b.status_id = request.POST.get('status_id')
        b.save()
        messages.success(request, 'Статус изменен')
    return redirect('admin_panel')

@staff_member_required
def view_review(request, booking_id):
    b = get_object_or_404(Booking, id=booking_id)
    try:
        return render(request, 'main/view_review.html', {'review': Review.objects.get(booking=b), 'booking': b})
    except Review.DoesNotExist:
        messages.error(request, 'Отзыва нет')
        return redirect('admin_panel')