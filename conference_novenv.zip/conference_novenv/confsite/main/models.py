from django.db import models
from django.contrib.auth.models import User

ROOM_CHOICES = [
    ('auditorium', 'Аудитория'),
    ('coworking', 'Коворкинг'),
    ('cinema', 'Кинозал'),
]

PAYMENT_CHOICES = [
    ('cash', 'Наличными'),
    ('card', 'Банковской картой'),
    ('transfer', 'Безналичный перевод'),
]

class BookingStatus(models.Model):
    name = models.CharField(max_length=50)
    def __str__(self):
        return self.name

class Room(models.Model):
    name = models.CharField(max_length=100)
    room_type = models.CharField(max_length=20, choices=ROOM_CHOICES)
    capacity = models.IntegerField()
    price_per_hour = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True)
    
    # ⭐ КАРТИНКИ ДЛЯ ПОМЕЩЕНИЙ:
    # 1. Создай папку static/images/rooms/
    # 2. Положи туда файлы: auditorium.jpg, coworking.jpg, cinema.jpg
    # 3. Раскомментируй строку ниже
    # 4. Выполни: python manage.py makemigrations && python manage.py migrate
    # image = models.ImageField(upload_to='rooms/', null=True, blank=True)
    
    def __str__(self):
        return f"{self.get_room_type_display()} - {self.name}"

class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    event_date = models.DateField()
    start_time = models.TimeField()
    duration_hours = models.IntegerField(default=2)
    payment_method = models.CharField(max_length=10, choices=PAYMENT_CHOICES)
    status = models.ForeignKey(BookingStatus, on_delete=models.SET_NULL, null=True)
    created_at = models.DateField(auto_now_add=True)
    
    def __str__(self):
        return f"Бронирование #{self.id}"

class Review(models.Model):
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE)
    text = models.TextField()
    rating = models.IntegerField(default=5)
    created_at = models.DateField(auto_now_add=True)
    
    def __str__(self):
        return f"Отзыв к #{self.booking.id}"